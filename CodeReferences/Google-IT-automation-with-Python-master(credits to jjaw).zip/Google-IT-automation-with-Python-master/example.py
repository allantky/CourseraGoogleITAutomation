#!/usr/bin/env python3

def git_operation():
  print("I am adding example.py file to the remote repository.")

git_operation()
